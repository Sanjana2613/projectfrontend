<?php include('server.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login | Road Maintenance Reviews</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- Font Awesome -->
  <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

  <!-- Custom Styles (Optional) -->
  <link rel="stylesheet" href="style.css"/>
</head>
<body class="bg-gray-100 font-[Poppins]">
  <div class="min-h-screen flex items-center justify-center">
    <div class="grid grid-cols-1 md:grid-cols-2 bg-white shadow-lg rounded-lg overflow-hidden max-w-4xl w-full">
      
      <!-- Left Panel -->
      <div class="bg-orange-100 p-10 flex flex-col items-center justify-center">
        <h1 class="text-3xl font-bold mb-4">Welcome Back!</h1>
        <p class="text-center text-gray-700 mb-6">Login to access your account and share your road maintenance reviews.</p>
        <img src="consrt.png" alt="Under Construction" class="w-64 h-auto">
      </div>

      <!-- Right Panel / Login Form -->
      <div class="p-10">
        <h2 class="text-2xl font-semibold mb-6 text-center">Login</h2>

        <?php include('errors.php'); ?>

        <form action="login.php" method="post" class="space-y-4">
          <!-- Username -->
          <div>
            <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
            <div class="flex items-center border border-gray-300 rounded px-3 py-2">
              <i class="fa-solid fa-user text-gray-500 mr-2"></i>
              <input type="text" name="username" id="username" class="w-full outline-none" placeholder="Your username" value="<?php echo $username; ?>" required>
            </div>
          </div>
          
          <!-- Password -->
          <div>
            <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
            <div class="flex items-center border border-gray-300 rounded px-3 py-2">
              <i class="fa-solid fa-lock text-gray-500 mr-2"></i>
              <input type="password" name="password" id="password" class="w-full outline-none" placeholder="********" required>
            </div>
          </div>

          <!-- Submit Button -->
          <button type="submit" name="login_user" class="w-full bg-orange-500 hover:bg-orange-600 text-white py-2 rounded transition duration-200">
            Login
          </button>
        </form>

        <!-- Divider -->
        <div class="my-6 text-center text-gray-500">or login with</div>

        <!-- Social Login -->
        <div class="flex justify-center space-x-4">
          <a href="#" class="text-red-500 text-xl"><i class="fab fa-google"></i></a>
          <a href="#" class="text-blue-600 text-xl"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="text-gray-800 text-xl"><i class="fab fa-github"></i></a>
        </div>

        <!-- Sign Up Link -->
        <p class="text-center mt-6 text-sm">
          Not yet a member? 
          <a href="register.php" class="text-orange-500 hover:underline">Sign up</a>
        </p>
      </div>
    </div>
  </div>
</body>
</html>
