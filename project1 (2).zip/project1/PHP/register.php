<?php include('server.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register | Road Maintenance Reviews</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- Font Awesome -->
  <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

  <!-- Custom Styles (Optional) -->
  <link rel="stylesheet" href="style.css"/>
</head>
<body class="bg-gray-100 font-[Poppins]">

  <div class="min-h-screen flex items-center justify-center px-4">
    <div class="grid grid-cols-1 md:grid-cols-2 bg-white shadow-2xl rounded-2xl overflow-hidden max-w-4xl w-full">

      <!-- Left Panel -->
      <div class="bg-orange-100 p-10 flex flex-col items-center justify-center text-center">
        <h1 class="text-4xl font-extrabold text-orange-600 mb-4">Welcome!</h1>
        <p class="text-gray-700 text-lg mb-6">Join the effort to improve roads. Your voice matters.</p>
        <img src="consrt.png" alt="Construction Image" class="w-64 h-auto">
      </div>

      <!-- Registration Form -->
      <div class="p-10">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">Create Your Account</h2>

        <?php include('errors.php'); ?>

        <form action="register.php" method="post" class="space-y-5">

          <!-- Username -->
          <div>
            <label for="username" class="block mb-1 text-sm font-medium text-gray-700">Username</label>
            <div class="flex items-center border rounded px-3 py-2">
              <i class="fa-solid fa-user text-gray-500 mr-2"></i>
              <input type="text" name="username" id="username" placeholder="Your username"
                     class="w-full focus:outline-none" value="<?php echo $username; ?>" required>
            </div>
          </div>

          <!-- Email -->
          <div>
            <label for="email" class="block mb-1 text-sm font-medium text-gray-700">Email</label>
            <div class="flex items-center border rounded px-3 py-2">
              <i class="fa-solid fa-envelope text-gray-500 mr-2"></i>
              <input type="email" name="email" id="email" placeholder="you@example.com"
                     class="w-full focus:outline-none" value="<?php echo $email; ?>" required>
            </div>
          </div>

          <!-- Password -->
          <div>
            <label for="password_1" class="block mb-1 text-sm font-medium text-gray-700">Password</label>
            <div class="flex items-center border rounded px-3 py-2">
              <i class="fa-solid fa-lock text-gray-500 mr-2"></i>
              <input type="password" name="password_1" id="password_1" placeholder="********"
                     class="w-full focus:outline-none" required>
            </div>
          </div>

          <!-- Confirm Password -->
          <div>
            <label for="password_2" class="block mb-1 text-sm font-medium text-gray-700">Confirm Password</label>
            <div class="flex items-center border rounded px-3 py-2">
              <i class="fa-solid fa-lock text-gray-500 mr-2"></i>
              <input type="password" name="password_2" id="password_2" placeholder="********"
                     class="w-full focus:outline-none" required>
            </div>
          </div>

          <!-- Register Button -->
          <button type="submit" name="reg_user"
                  class="w-full bg-orange-500 text-white py-2 rounded hover:bg-orange-600 transition duration-200">
            Register
          </button>
        </form>

        <!-- Divider -->
        <div class="my-6 text-center text-gray-400">or sign up with</div>

        <!-- Social Login -->
        <div class="flex justify-center gap-6 text-2xl">
          <a href="#" class="text-red-500 hover:text-red-600"><i class="fab fa-google"></i></a>
          <a href="#" class="text-blue-600 hover:text-blue-700"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="text-gray-800 hover:text-black"><i class="fab fa-github"></i></a>
        </div>

        <!-- Sign In Redirect -->
        <p class="text-center mt-6 text-sm text-gray-600">
          Already a member?
          <a href="login.php" class="text-orange-500 hover:underline">Sign in</a>
        </p>
      </div>
    </div>
  </div>

</body>
</html>
